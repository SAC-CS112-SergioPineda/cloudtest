package com.example.cloudtestapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudtestappApplicationTests {

	@Test
	void contextLoads() {
	}

}
